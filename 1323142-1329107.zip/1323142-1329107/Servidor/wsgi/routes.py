import psycopg2
import os
import json
from time import gmtime, strftime
from flask import Flask
from flask import json
from flask import request


app = Flask(__name__)
# Keeps Flask from swallowing error messages
app.config['PROPAGATE_EXCEPTIONS'] = True


@app.route("/putofunciona", methods = ['GET', 'POST'])
def api_message():
	if request.method == 'GET':	
		return imprimir_registros()
	elif request.method == 'POST':	
		parsed_json = json.loads(json.dumps(request.json))
		guardar_registro(parsed_json['Memoria'], parsed_json['Fecha'], parsed_json['Hora'])
		return parsed_json['Memoria'] + parsed_json['Fecha'] + parsed_json['Hora']

	else:
		return "Unsupported"

def get_cursor():
 conn = psycopg2.connect(database=os.environ['OPENSHIFT_APP_NAME'],
               user=os.environ['OPENSHIFT_POSTGRESQL_DB_USERNAME'],
               password=os.environ['OPENSHIFT_POSTGRESQL_DB_PASSWORD'],
               host=os.environ['OPENSHIFT_POSTGRESQL_DB_HOST'],
               port=os.environ['OPENSHIFT_POSTGRESQL_DB_PORT'] )
 cursor = conn.cursor()
 return cursor

def close_cursor(cursor):
 conn = cursor.connection
 conn.commit()
 cursor.close()
 conn.close()



def imprimir_registros():

 	cursor = get_cursor()

 	sql = "SELECT * FROM registros;"
 	cursor.execute(sql)
 
	mensaje = ""
 	for registro in cursor:
		mensaje += "Memoria: " + registro[0]
		mensaje += ", Fecha: " + registro[1]
		mensaje += ", Hora: " + registro[2]
		mensaje += "\n"
	close_cursor(cursor)
 	
	return mensaje

def guardar_registro(memFree, fecha, hora):
	
	cursor = get_cursor()

 	cursor.execute("INSERT INTO registros VALUES (%s,%s,%s)",(memFree, fecha,hora))
		
	close_cursor(cursor)
	
if __name__ == "__main__":
   app.run()

