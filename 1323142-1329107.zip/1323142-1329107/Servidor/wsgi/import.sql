DROP TABLE IF EXISTS short_adjective;


BEGIN;

CREATE TABLE registros ( 

free VARCHAR(100),
fecha VARCHAR(30),
hora VARCHAR(35),
PRIMARY KEY(fecha,hora)

);

COMMIT;

